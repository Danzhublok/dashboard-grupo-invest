import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { _ as useStore, d as quinzena1Rep, f as quinzena2Rep, o as lucroColaborador, r as brl } from "./grupo-invest-logo-wQIwvroT.mjs";
import { f as Plus, t as X } from "../_libs/lucide-react.mjs";
import { a as CardHeader, c as cn, i as CardContent, n as Button, o as CardTitle, r as Card, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Badge } from "./badge-DHIGAyFT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/vendas-DAU1Mcox.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function VendasPage() {
	const { dados, registrarVenda } = useStore();
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const [selectedRep, setSelectedRep] = (0, import_react.useState)(dados.representacoes[0]?.id ?? "");
	const [selectedColaborador, setSelectedColaborador] = (0, import_react.useState)("");
	const [valorVenda, setValorVenda] = (0, import_react.useState)("");
	const [quinzena, setQuinzena] = (0, import_react.useState)("quinzena1");
	const colaboradoresDaRep = (0, import_react.useMemo)(() => dados.representacoes.find((rep) => rep.id === selectedRep) ?? dados.representacoes[0], [dados.representacoes, selectedRep])?.colaboradores ?? [];
	(0, import_react.useEffect)(() => {
		if (!selectedRep && dados.representacoes.length > 0) {
			const primeiraRep = dados.representacoes[0];
			setSelectedRep(primeiraRep.id);
			setSelectedColaborador(primeiraRep.colaboradores[0]?.id ?? "");
		}
	}, [dados.representacoes, selectedRep]);
	(0, import_react.useEffect)(() => {
		const repAtual = dados.representacoes.find((rep) => rep.id === selectedRep);
		if (!repAtual) return;
		if (!repAtual.colaboradores.some((colaborador) => colaborador.id === selectedColaborador)) setSelectedColaborador(repAtual.colaboradores[0]?.id ?? "");
	}, [
		dados.representacoes,
		selectedColaborador,
		selectedRep
	]);
	const onAbrirModal = () => {
		const primeiraRep = dados.representacoes[0];
		setSelectedRep(primeiraRep?.id ?? "");
		setSelectedColaborador(primeiraRep?.colaboradores[0]?.id ?? "");
		setValorVenda("");
		setQuinzena("quinzena1");
		setDialogOpen(true);
	};
	const onSalvarVenda = () => {
		const valor = Number(valorVenda);
		if (!selectedRep || !selectedColaborador || !valor || valor <= 0) return;
		registrarVenda({
			representationId: selectedRep,
			collaboratorId: selectedColaborador,
			valor,
			quinzena
		});
		setDialogOpen(false);
		setValorVenda("");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Vendas",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground",
						children: "Registro dinâmico"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-bold tracking-tight",
						children: "Vendas"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: onAbrirModal,
						className: "gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Registrar venda"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid gap-6 md:grid-cols-2 xl:grid-cols-3",
					children: dados.representacoes.map((rep) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
							className: "flex flex-row items-center gap-3 border-b border-border/60 pb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: rep.logo,
									alt: "",
									className: "size-10 object-contain"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
										className: "text-base",
										children: rep.nome
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: rep.representante
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "secondary",
									children: rep.colaboradores.length
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "pt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "1ª quinzena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: brl(quinzena1Rep(rep)) })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: "2ª quinzena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: brl(quinzena2Rep(rep)) })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between border-t border-border/50 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-semibold",
											children: "Lucro"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-accent",
											children: brl(rep.colaboradores.reduce((sum, c) => sum + lucroColaborador(c), 0))
										})]
									})
								]
							})
						})]
					}, rep.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid gap-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
								className: "text-lg",
								children: "Últimas vendas registradas"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "secondary",
								children: dados.vendas.length
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "space-y-3",
							children: dados.vendas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Nenhuma venda registrada ainda."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-2",
								children: dados.vendas.slice(0, 8).map((venda) => {
									const rep = dados.representacoes.find((r) => r.id === venda.representationId);
									const colaborador = rep?.colaboradores.find((c) => c.id === venda.collaboratorId);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border/60 px-4 py-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-semibold",
											children: rep?.nome ?? "Representação"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												colaborador?.nome ?? "Colaborador",
												" · ",
												venda.quinzena === "quinzena1" ? "1ª quinzena" : "2ª quinzena"
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-right",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-bold text-accent",
												children: brl(venda.valor)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-[11px] uppercase tracking-wide text-muted-foreground",
												children: new Date(venda.data).toLocaleDateString("pt-BR")
											})]
										})]
									}, venda.id);
								})
							})
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
					open: dialogOpen,
					onOpenChange: setDialogOpen,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Registrar nova venda" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Escolha a representação, o colaborador e a quinzena para registrar automaticamente o valor." })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 py-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-sm font-medium",
											children: "Representação"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
											value: selectedRep,
											onChange: (event) => {
												const nextValue = event.target.value;
												setSelectedRep(nextValue);
												const nextRep = dados.representacoes.find((r) => r.id === nextValue);
												setSelectedColaborador(nextRep?.colaboradores[0]?.id ?? "");
											},
											children: dados.representacoes.map((rep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: rep.id,
												children: rep.nome
											}, rep.id))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-sm font-medium",
											children: "Colaborador"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
											value: selectedColaborador,
											onChange: (event) => setSelectedColaborador(event.target.value),
											children: [colaboradoresDaRep.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "Sem colaboradores"
											}), colaboradoresDaRep.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: c.id,
												children: c.nome
											}, c.id))]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-sm font-medium",
											children: "Valor da venda"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "1",
											className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
											placeholder: "Ex.: 12500",
											value: valorVenda,
											onChange: (event) => setValorVenda(event.target.value)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-sm font-medium",
											children: "Quinzena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
											value: quinzena,
											onChange: (event) => setQuinzena(event.target.value),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "quinzena1",
												children: "1ª Quinzena"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "quinzena2",
												children: "2ª Quinzena"
											})]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								onClick: () => setDialogOpen(false),
								children: "Cancelar"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								onClick: onSalvarVenda,
								children: "Salvar venda"
							})] })
						]
					})
				})
			]
		})
	});
}
//#endregion
export { VendasPage as component };
