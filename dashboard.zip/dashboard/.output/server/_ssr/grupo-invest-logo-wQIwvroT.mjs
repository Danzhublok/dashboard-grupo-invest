import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/grupo-invest-logo-wQIwvroT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var dadosIniciais = {
	metaMensal: 0,
	saidas: [],
	vendas: [],
	representacoes: [],
	metasEquipe: {},
	metasColaborador: {}
};
var lucroColaborador = (c) => Number(c.quinzena1 || 0) + Number(c.quinzena2 || 0);
var lucroColaboradorPorPeriodo = (c, periodo = "geral") => {
	if (periodo === "quinzena1") return Number(c.quinzena1 || 0);
	if (periodo === "quinzena2") return Number(c.quinzena2 || 0);
	return lucroColaborador(c);
};
var quinzena1Rep = (r) => r.colaboradores.reduce((s, x) => s + Number(x.quinzena1 || 0), 0);
var quinzena2Rep = (r) => r.colaboradores.reduce((s, x) => s + Number(x.quinzena2 || 0), 0);
var lucroMensal = (r) => quinzena1Rep(r) + quinzena2Rep(r);
var lucroRepresentacaoPorPeriodo = (r, periodo = "geral") => {
	if (periodo === "quinzena1") return quinzena1Rep(r);
	if (periodo === "quinzena2") return quinzena2Rep(r);
	return lucroMensal(r);
};
var cotasRep = (r) => r.colaboradores.reduce((s, x) => s + Number(x.cotas || 0), 0);
var somaLucro = (reps) => reps.reduce((s, r) => s + lucroMensal(r), 0);
var somaLucroPorPeriodo = (reps, periodo = "geral") => reps.reduce((s, r) => s + lucroRepresentacaoPorPeriodo(r, periodo), 0);
var somaCotas = (reps) => reps.reduce((s, r) => s + cotasRep(r), 0);
var brl = (v) => v.toLocaleString("pt-BR", {
	style: "currency",
	currency: "BRL",
	maximumFractionDigits: 0
});
var novoId = () => {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (character) => {
		const random = Math.random() * 16 | 0;
		return (character === "x" ? random : random & 3 | 8).toString(16);
	});
};
var supabase = createClient("https://ojycisopeuoailqcglcy.supabase.co", "sb_publishable_p1mIQzkdgh_p304JJPzcqA_J_7HIYJ3");
var AuthContext = (0, import_react.createContext)(null);
var LOCAL_SESSION_KEY = "grupo-invest-session";
function AuthProvider({ children }) {
	const [session, setSession] = (0, import_react.useState)(null);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let active = true;
		const loadSession = async () => {
			if (supabase) {
				const { data } = await supabase.auth.getSession();
				if (data.session && active) {
					const loaded = await loadSupabaseProfile(data.session.user.id, data.session.user.email);
					if (active) setSession(loaded);
				}
			} else {
				const raw = localStorage.getItem(LOCAL_SESSION_KEY);
				if (raw && active) setSession(JSON.parse(raw));
			}
			if (active) setReady(true);
		};
		loadSession();
		const listener = supabase?.auth.onAuthStateChange((_event, authSession) => {
			if (!authSession) setSession(null);
		});
		return () => {
			active = false;
			listener?.data.subscription.unsubscribe();
		};
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		session,
		ready,
		login: async (email, password) => {
			if (!supabase) {
				if (email.toLowerCase() === "admin" && password === "invest123") {
					const localSession = {
						userId: "local-admin",
						fullName: "Administrador",
						email: "admin",
						role: "admin"
					};
					localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(localSession));
					setSession(localSession);
					return null;
				}
				return "Configure o Supabase para acessar contas de representantes.";
			}
			const loginEmail = email.includes("@") ? email : `${email.trim().toLowerCase()}@accounts.grupoinvest.local`;
			const { data, error } = await supabase.auth.signInWithPassword({
				email: loginEmail,
				password
			});
			if (error || !data.user) return error?.message ?? "Não foi possível entrar.";
			const loaded = await loadSupabaseProfile(data.user.id, data.user.email);
			setSession(loaded);
			return null;
		},
		logout: async () => {
			localStorage.removeItem(LOCAL_SESSION_KEY);
			if (supabase) await supabase.auth.signOut();
			setSession(null);
		}
	}), [ready, session]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value,
		children
	});
}
async function loadSupabaseProfile(userId, email) {
	if (!supabase) return {
		userId,
		email,
		fullName: email ?? "Usuário",
		role: "representante"
	};
	const { data: profile } = await supabase.from("profiles").select("full_name, role").eq("id", userId).single();
	const { data: membership } = await supabase.from("representation_members").select("representation_id, representation:representations(name)").eq("user_id", userId).limit(1).maybeSingle();
	const representation = membership?.representation;
	return {
		userId,
		email,
		fullName: profile?.full_name ?? email ?? "Usuário",
		role: profile?.role ?? "representante",
		representationId: membership?.representation_id,
		representationName: representation?.name
	};
}
function useAuth() {
	const context = (0, import_react.useContext)(AuthContext);
	if (!context) throw new Error("useAuth precisa estar dentro de AuthProvider");
	return context;
}
var StoreContext = (0, import_react.createContext)(null);
function StoreProvider({ children, representationId, representationName }) {
	const { session } = useAuth();
	const [dados, setDados] = (0, import_react.useState)(dadosIniciais);
	const [pronto, setPronto] = (0, import_react.useState)(false);
	const [erro, setErro] = (0, import_react.useState)(null);
	const [usuarios, setUsuarios] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		let active = true;
		const load = async () => {
			if (!supabase) {
				if (active) setPronto(true);
				return;
			}
			setErro(null);
			const inicioMes = /* @__PURE__ */ new Date();
			inicioMes.setDate(1);
			const inicioProximoMes = new Date(inicioMes);
			inicioProximoMes.setMonth(inicioProximoMes.getMonth() + 1);
			const mesAtual = inicioMes.toISOString().slice(0, 10);
			const proximoMes = inicioProximoMes.toISOString().slice(0, 10);
			const responses = await Promise.all([
				supabase.from("representations").select("id, name, logo_url, representative_name"),
				supabase.from("collaborators").select("id, representation_id, full_name, role, avatar_url, quotas"),
				supabase.from("collaborator_results").select("collaborator_id, first_half, second_half").gte("month", mesAtual).lt("month", proximoMes),
				supabase.from("expenses").select("id, representation_id, reason, amount, occurred_on"),
				supabase.from("targets").select("representation_id, amount").gte("month", mesAtual).lt("month", proximoMes).order("month", { ascending: false }),
				supabase.from("profiles").select("id, full_name, username, role"),
				supabase.from("representation_members").select("user_id, representation_id, representation:representations(name)"),
				supabase.from("collaborator_targets").select("collaborator_id, amount").gte("month", mesAtual).lt("month", proximoMes),
				supabase.from("company_targets").select("amount").gte("month", mesAtual).lt("month", proximoMes).limit(1)
			]);
			const failed = responses.find((response) => response.error);
			if (failed) {
				if (active) {
					setErro(failed.error?.message ?? "Não foi possível carregar os dados do Supabase.");
					setPronto(true);
				}
				return;
			}
			const [{ data: reps }, { data: collaborators }, { data: results }, { data: expenses }, { data: targets }, { data: profiles }, { data: memberships }, { data: collaboratorTargets }, { data: companyTargets }] = responses;
			if (!active) return;
			const resultsByCollaborator = /* @__PURE__ */ new Map();
			(results ?? []).forEach((result) => {
				const previous = resultsByCollaborator.get(result.collaborator_id) ?? {
					first: 0,
					second: 0
				};
				resultsByCollaborator.set(result.collaborator_id, {
					first: previous.first + Number(result.first_half ?? 0),
					second: previous.second + Number(result.second_half ?? 0)
				});
			});
			const metasEquipe = Object.fromEntries((targets ?? []).map((target) => [target.representation_id, Number(target.amount ?? 0)]));
			const metasColaborador = Object.fromEntries((collaboratorTargets ?? []).map((target) => [target.collaborator_id, Number(target.amount ?? 0)]));
			setUsuarios((profiles ?? []).map((profile) => {
				const membership = (memberships ?? []).find((item) => item.user_id === profile.id);
				const representation = membership?.representation;
				return {
					id: profile.id,
					nome: profile.full_name,
					username: profile.username ?? void 0,
					role: profile.role,
					representationId: membership?.representation_id,
					representationName: representation?.name
				};
			}));
			(reps ?? []).find((representation) => representation.id === representationId || representation.name === representationName);
			setDados({
				metaMensal: Number(companyTargets?.[0]?.amount ?? 0),
				metasEquipe,
				metasColaborador,
				saidas: (expenses ?? []).map((expense) => ({
					id: expense.id,
					motivo: expense.reason,
					valor: Number(expense.amount),
					data: expense.occurred_on
				})),
				representacoes: (reps ?? []).map((rep) => ({
					id: rep.id,
					nome: rep.name,
					logo: rep.logo_url ?? "",
					representante: rep.representative_name ?? "A definir",
					colaboradores: (collaborators ?? []).filter((collaborator) => collaborator.representation_id === rep.id).map((collaborator) => {
						const result = resultsByCollaborator.get(collaborator.id) ?? {
							first: 0,
							second: 0
						};
						return {
							id: collaborator.id,
							nome: collaborator.full_name,
							cargo: collaborator.role,
							foto: collaborator.avatar_url ?? void 0,
							cotas: collaborator.quotas,
							quinzena1: result.first,
							quinzena2: result.second
						};
					})
				}))
			});
			setPronto(true);
		};
		load();
		return () => {
			active = false;
		};
	}, [
		representationId,
		representationName,
		session?.userId
	]);
	const dadosVisiveis = (0, import_react.useMemo)(() => representationId ? {
		...dados,
		representacoes: dados.representacoes.filter((rep) => rep.id === representationId || rep.nome === representationName)
	} : dados, [
		dados,
		representationId,
		representationName
	]);
	const value = (0, import_react.useMemo)(() => {
		const mapReps = (fn) => setDados((d) => ({
			...d,
			representacoes: d.representacoes.map(fn)
		}));
		const report = async (operation) => {
			const result = await operation;
			if (result.error) setErro(result.error.message);
		};
		return {
			dados: dadosVisiveis,
			pronto,
			erro,
			usuarios,
			setMeta: (v) => {
				setDados((d) => ({
					...d,
					metaMensal: v
				}));
				if (supabase) report(supabase.from("company_targets").upsert({
					month: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
					amount: v
				}, { onConflict: "month" }));
			},
			setMetaEquipe: (representationId, value) => {
				setDados((current) => ({
					...current,
					metasEquipe: {
						...current.metasEquipe,
						[representationId]: value
					}
				}));
				if (supabase) report(supabase.from("targets").upsert({
					representation_id: representationId,
					month: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
					amount: value
				}, { onConflict: "representation_id,month" }));
			},
			setMetaColaborador: (collaboratorId, value) => {
				setDados((current) => ({
					...current,
					metasColaborador: {
						...current.metasColaborador,
						[collaboratorId]: value
					}
				}));
				if (supabase) report(supabase.from("collaborator_targets").upsert({
					collaborator_id: collaboratorId,
					month: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
					amount: value
				}, { onConflict: "collaborator_id,month" }));
			},
			addRepresentacao: async (r) => {
				const id = r.id;
				setDados((d) => ({
					...d,
					representacoes: [...d.representacoes, {
						...r,
						id,
						colaboradores: []
					}]
				}));
				if (!supabase) return null;
				const { error: insertError } = await supabase.from("representations").insert({
					id,
					name: r.nome,
					logo_url: r.logo,
					representative_name: r.representante
				});
				if (insertError) {
					setErro(insertError.message);
					return null;
				}
				return null;
			},
			criarUsuario: async (representationId, username, password) => {
				if (!supabase) return null;
				const representation = dadosVisiveis.representacoes.find((item) => item.id === representationId);
				if (!representation) {
					setErro("Representação não encontrada.");
					return null;
				}
				const { data, error } = await supabase.functions.invoke("create-representative-account", { body: {
					representation_id: representation.id,
					representation_name: representation.nome,
					username,
					password
				} });
				if (error) {
					let message = error.message;
					const context = "context" in error ? error.context : void 0;
					if (context instanceof Response) try {
						message = (await context.clone().json()).error ?? message;
					} catch {}
					if (message.toLowerCase().includes("failed to send")) message = `${message}. Publique a Edge Function com: supabase functions deploy create-representative-account`;
					setErro(message);
					return null;
				}
				return data;
			},
			deleteUsuario: async (userId) => {
				if (!supabase) return false;
				const { error } = await supabase.rpc("delete_representative_account", { target_user_id: userId });
				if (error) {
					setErro(error.message);
					return false;
				}
				setUsuarios((current) => current.filter((user) => user.id !== userId));
				return true;
			},
			alterarSenhaUsuario: async (userId, password) => {
				if (!supabase) return false;
				const { error } = await supabase.functions.invoke("update-representative-password", { body: {
					target_user_id: userId,
					password
				} });
				if (error) {
					let message = error.message;
					const context = "context" in error ? error.context : void 0;
					if (context instanceof Response) try {
						message = (await context.clone().json()).error ?? message;
					} catch {}
					setErro(message);
					return false;
				}
				return true;
			},
			updateRepresentacao: (id, patch) => {
				mapReps((r) => r.id === id ? {
					...r,
					...patch
				} : r);
				if (supabase) report(supabase.from("representations").update({
					name: patch.nome,
					logo_url: patch.logo,
					representative_name: patch.representante
				}).eq("id", id));
			},
			removeRepresentacao: (id) => {
				setDados((d) => ({
					...d,
					representacoes: d.representacoes.filter((r) => r.id !== id)
				}));
				if (supabase) report(supabase.from("representations").delete().eq("id", id));
			},
			addColaborador: (repId, c) => {
				mapReps((r) => r.id === repId ? {
					...r,
					colaboradores: [...r.colaboradores, c]
				} : r);
				if (supabase) report(supabase.from("collaborators").insert({
					id: c.id,
					representation_id: repId,
					full_name: c.nome,
					role: c.cargo,
					avatar_url: c.foto,
					quotas: Number(c.cotas || 0)
				}));
			},
			updateColaborador: (repId, colId, patch) => {
				mapReps((r) => r.id === repId ? {
					...r,
					colaboradores: r.colaboradores.map((c) => c.id === colId ? {
						...c,
						...patch
					} : c)
				} : r);
				if (supabase) {
					report(supabase.from("collaborators").update({
						full_name: patch.nome,
						role: patch.cargo,
						avatar_url: patch.foto,
						quotas: patch.cotas === void 0 ? void 0 : Number(patch.cotas || 0)
					}).eq("id", colId));
					const current = dadosVisiveis.representacoes.flatMap((representation) => representation.colaboradores).find((collaborator) => collaborator.id === colId);
					if (current) {
						const next = {
							...current,
							...patch
						};
						report(supabase.from("collaborator_results").upsert({
							collaborator_id: colId,
							month: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
							first_half: Number(next.quinzena1 || 0),
							second_half: Number(next.quinzena2 || 0),
							quotas: Number(next.cotas || 0)
						}, { onConflict: "collaborator_id,month" }));
					}
				}
			},
			removeColaborador: (repId, colId) => {
				mapReps((r) => r.id === repId ? {
					...r,
					colaboradores: r.colaboradores.filter((c) => c.id !== colId)
				} : r);
				if (supabase) report(supabase.from("collaborators").delete().eq("id", colId));
			},
			addSaida: (saida) => {
				setDados((d) => ({
					...d,
					saidas: [...d.saidas, saida]
				}));
				if (supabase && session?.userId && dadosVisiveis.representacoes[0]) report(supabase.from("expenses").insert({
					id: saida.id,
					representation_id: dadosVisiveis.representacoes[0].id,
					reason: saida.motivo,
					amount: saida.valor,
					occurred_on: saida.data,
					created_by: session.userId
				}));
			},
			removeSaida: (id) => {
				setDados((d) => ({
					...d,
					saidas: d.saidas.filter((s) => s.id !== id)
				}));
				if (supabase) report(supabase.from("expenses").delete().eq("id", id));
			},
			registrarVenda: ({ representationId, collaboratorId, valor, quinzena }) => {
				const month = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
				const sale = {
					id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
					representationId,
					collaboratorId,
					valor,
					quinzena,
					data: (/* @__PURE__ */ new Date()).toISOString()
				};
				setDados((current) => ({
					...current,
					vendas: [sale, ...current.vendas],
					representacoes: current.representacoes.map((rep) => {
						if (rep.id !== representationId) return rep;
						return {
							...rep,
							colaboradores: rep.colaboradores.map((collaborator) => {
								if (collaborator.id !== collaboratorId) return collaborator;
								const proximoValor = Number(valor);
								const atualQuinzena1 = Number(collaborator.quinzena1 || 0);
								const atualQuinzena2 = Number(collaborator.quinzena2 || 0);
								const atualCotas = Number(collaborator.cotas || 0);
								return {
									...collaborator,
									cotas: atualCotas + 1,
									quinzena1: quinzena === "quinzena1" ? atualQuinzena1 + proximoValor : atualQuinzena1,
									quinzena2: quinzena === "quinzena2" ? atualQuinzena2 + proximoValor : atualQuinzena2
								};
							})
						};
					})
				}));
				if (supabase) {
					const target = dadosVisiveis.representacoes.flatMap((rep) => rep.colaboradores).find((c) => c.id === collaboratorId);
					if (target) {
						const updatedQuinzena1 = quinzena === "quinzena1" ? Number(target.quinzena1 || 0) + Number(valor) : Number(target.quinzena1 || 0);
						const updatedQuinzena2 = quinzena === "quinzena2" ? Number(target.quinzena2 || 0) + Number(valor) : Number(target.quinzena2 || 0);
						const updatedCotas = Number(target.cotas || 0) + 1;
						report(supabase.from("collaborator_results").upsert({
							collaborator_id: collaboratorId,
							month,
							first_half: updatedQuinzena1,
							second_half: updatedQuinzena2,
							quotas: updatedCotas
						}, { onConflict: "collaborator_id,month" }));
						report(supabase.from("collaborators").update({ quotas: updatedCotas }).eq("id", collaboratorId));
					}
				}
			},
			salvar: () => void 0,
			resetar: () => setDados(dadosIniciais)
		};
	}, [
		dados,
		dadosVisiveis,
		erro,
		pronto,
		session?.userId,
		usuarios
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreContext.Provider, {
		value,
		children
	});
}
function useStore() {
	const ctx = (0, import_react.useContext)(StoreContext);
	if (!ctx) throw new Error("useStore precisa estar dentro de StoreProvider");
	return ctx;
}
var grupo_invest_logo_default = "/assets/grupo-invest-logo-BYs1KUjT.jpg";
//#endregion
export { useStore as _, grupo_invest_logo_default as a, lucroMensal as c, quinzena1Rep as d, quinzena2Rep as f, useAuth as g, somaLucroPorPeriodo as h, cotasRep as i, lucroRepresentacaoPorPeriodo as l, somaLucro as m, StoreProvider as n, lucroColaborador as o, somaCotas as p, brl as r, lucroColaboradorPorPeriodo as s, AuthProvider as t, novoId as u };
