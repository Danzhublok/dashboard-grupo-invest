import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore } from "./grupo-invest-logo-wQIwvroT.mjs";
import { S as EyeOff, T as Check, i as UserPlus, p as Pencil, s as Trash2, t as X, u as Save, x as Eye, y as KeyRound } from "../_libs/lucide-react.mjs";
import { a as CardHeader, i as CardContent, n as Button, o as CardTitle, r as Card, s as Input, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Label } from "./label-DCLq8y_H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/usuarios-CMNxxk0U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Usuarios() {
	const { dados, usuarios, criarUsuario, alterarSenhaUsuario, deleteUsuario } = useStore();
	const [representationId, setRepresentationId] = (0, import_react.useState)("");
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [credentials, setCredentials] = (0, import_react.useState)(null);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [editingUserId, setEditingUserId] = (0, import_react.useState)(null);
	const [editingPassword, setEditingPassword] = (0, import_react.useState)("");
	const [showEditingPassword, setShowEditingPassword] = (0, import_react.useState)(false);
	const [savingPassword, setSavingPassword] = (0, import_react.useState)(false);
	const createUser = async () => {
		setCreating(true);
		setCredentials(null);
		const result = await criarUsuario(representationId, username, password);
		setCredentials(result);
		setCreating(false);
		if (result) {
			setUsername("");
			setPassword("");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Usuários dos representantes",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-4xl flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: "Usuários"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Crie um acesso e vincule o representante à representação correta."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-5" }), " Novo usuário"]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "grid gap-4 md:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "usuario-representacao",
									children: "Representação"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									id: "usuario-representacao",
									value: representationId,
									onChange: (event) => setRepresentationId(event.target.value),
									className: "h-10 w-full rounded-md border border-input bg-background px-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "Selecione uma representação"
									}), dados.representacoes.map((representation) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: representation.id,
										children: representation.nome
									}, representation.id))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "novo-usuario",
									children: "Usuário"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "novo-usuario",
									value: username,
									onChange: (event) => setUsername(event.target.value),
									placeholder: "Ex.: reinaldo",
									autoComplete: "off"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "nova-senha",
									children: "Senha"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "nova-senha",
										type: showPassword ? "text" : "password",
										value: password,
										onChange: (event) => setPassword(event.target.value),
										placeholder: "Ex.: romarepresent",
										autoComplete: "new-password",
										className: "pr-10"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "ghost",
										size: "icon",
										className: "absolute right-0 top-0",
										"aria-label": showPassword ? "Ocultar senha" : "Exibir senha",
										onClick: () => setShowPassword((current) => !current),
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => void createUser(),
									disabled: !representationId || !username.trim() || password.length < 8 || creating,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" }), creating ? "Criando acesso..." : "Criar login"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: "A senha precisa ter pelo menos 8 caracteres e não será salva em texto no banco."
								})]
							})
						]
					})]
				}),
				credentials && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "border-accent/40 bg-accent/10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-5" }), " Login criado"]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Entregue estas credenciais ao representante. Elas não serão exibidas novamente." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Usuário:" }),
								" ",
								credentials.username
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Senha:" }),
								" ",
								credentials.password
							] })
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Logins cadastrados" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "divide-y divide-border/60 p-0",
						children: usuarios.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "p-6 text-sm text-muted-foreground",
							children: "Nenhum usuário cadastrado."
						}) : usuarios.map((user) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: user.username || user.nome
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: user.role === "admin" ? "Administrador" : user.representationName || "Sem representação"
									})]
								}),
								user.role !== "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": `Editar senha de ${user.username || user.nome}`,
										onClick: () => {
											setEditingUserId(user.id);
											setEditingPassword("");
											setShowEditingPassword(false);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										size: "icon",
										"aria-label": `Excluir usuário ${user.username || user.nome}`,
										onClick: () => {
											if (window.confirm(`Excluir o usuário ${user.username || user.nome}?`)) deleteUsuario(user.id);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
									})]
								}),
								editingUserId === user.id && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex basis-full items-end gap-2 border-t border-border/60 pt-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1 space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
												htmlFor: `senha-${user.id}`,
												children: "Nova senha"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
													id: `senha-${user.id}`,
													type: showEditingPassword ? "text" : "password",
													value: editingPassword,
													onChange: (event) => setEditingPassword(event.target.value),
													placeholder: "Mínimo de 8 caracteres",
													autoComplete: "new-password",
													className: "pr-10"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													type: "button",
													variant: "ghost",
													size: "icon",
													className: "absolute right-0 top-0",
													"aria-label": showEditingPassword ? "Ocultar senha" : "Exibir senha",
													onClick: () => setShowEditingPassword((current) => !current),
													children: showEditingPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											size: "icon",
											"aria-label": "Salvar nova senha",
											disabled: editingPassword.length < 8 || savingPassword,
											onClick: async () => {
												setSavingPassword(true);
												const saved = await alterarSenhaUsuario(user.id, editingPassword);
												setSavingPassword(false);
												if (saved) {
													setEditingUserId(null);
													setEditingPassword("");
												}
											},
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											variant: "ghost",
											size: "icon",
											"aria-label": "Cancelar edição da senha",
											onClick: () => setEditingUserId(null),
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
										})
									]
								})
							]
						}, user.id))
					})]
				})
			]
		})
	});
}
//#endregion
export { Usuarios as component };
