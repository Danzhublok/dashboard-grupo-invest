import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore, c as lucroMensal, g as useAuth, m as somaLucro, r as brl, u as novoId } from "./grupo-invest-logo-wQIwvroT.mjs";
import { T as Check, b as ImagePlus, d as RotateCcw, f as Plus, s as Trash2 } from "../_libs/lucide-react.mjs";
import { a as CardHeader, i as CardContent, n as Button, o as CardTitle, r as Card, s as Input, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Label } from "./label-DCLq8y_H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/configuracoes-o2helFTk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var lerArquivo = (file) => new Promise((resolve, reject) => {
	const reader = new FileReader();
	reader.onload = () => resolve(String(reader.result));
	reader.onerror = reject;
	reader.readAsDataURL(file);
});
function LogoUpload({ value, onChange }) {
	const ref = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-12 items-center justify-center rounded-lg border border-border/60 bg-background/60",
				children: value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: value,
					alt: "Logo",
					className: "size-10 object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5 text-muted-foreground" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				onClick: () => ref.current?.click(),
				children: "Trocar logo"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				type: "file",
				accept: "image/*",
				className: "hidden",
				onChange: async (e) => {
					const file = e.target.files?.[0];
					if (file) onChange(await lerArquivo(file));
					e.target.value = "";
				}
			})
		]
	});
}
function FotoUpload({ value, onChange }) {
	const ref = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-10 shrink-0 items-center justify-center overflow-hidden rounded-full border border-border/60 bg-background/60",
				children: value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: value,
					alt: "Foto do colaborador",
					className: "size-full object-cover"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4 text-muted-foreground" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				onClick: () => ref.current?.click(),
				children: value ? "Trocar foto" : "Adicionar foto"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref,
				type: "file",
				accept: "image/*",
				className: "hidden",
				onChange: async (e) => {
					const file = e.target.files?.[0];
					if (file) onChange(await lerArquivo(file));
					e.target.value = "";
				}
			})
		]
	});
}
function RepEditor({ rep, isAdmin }) {
	const { updateRepresentacao, removeRepresentacao, addColaborador, updateColaborador, removeColaborador, salvar } = useStore();
	const [novoNome, setNovoNome] = (0, import_react.useState)("");
	const [salvo, setSalvo] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "surface-card border-border/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
			className: "flex flex-wrap items-center justify-between gap-3 border-b border-border/60 pb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: rep.logo,
					alt: `Logo ${rep.nome}`,
					className: "size-10 shrink-0 object-contain"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "truncate text-lg",
						children: rep.nome
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [brl(lucroMensal(rep)), " no mês"]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => {
						salvar();
						setSalvo(true);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }),
						" ",
						salvo ? "Salvo" : "Salvar"
					]
				}), isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					className: "text-destructive",
					onClick: () => removeRepresentacao(rep.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), " Remover"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-5 pt-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `nome-${rep.id}`,
							children: "Nome da representação"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `nome-${rep.id}`,
							value: rep.nome,
							disabled: !isAdmin,
							onChange: (e) => updateRepresentacao(rep.id, { nome: e.target.value })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: `resp-${rep.id}`,
							children: "Representante"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: `resp-${rep.id}`,
							value: rep.representante,
							disabled: !isAdmin,
							onChange: (e) => updateRepresentacao(rep.id, { representante: e.target.value })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Logo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoUpload, {
							value: rep.logo,
							onChange: (logo) => updateRepresentacao(rep.id, { logo })
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold",
						children: "Colaboradores"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden gap-2 px-1 text-xs text-muted-foreground lg:grid lg:grid-cols-[1.4fr_1.4fr_0.8fr_0.5fr_1fr_1fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Nome" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Foto" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cargo" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Cotas" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1ª quinzena (R$)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "2ª quinzena (R$)" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
						]
					}),
					rep.colaboradores.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 rounded-xl border border-border/60 p-2 sm:grid-cols-2 lg:grid-cols-[1.4fr_1.4fr_0.8fr_0.5fr_1fr_1fr_auto] lg:border-0 lg:p-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: c.nome,
								"aria-label": "Nome do colaborador",
								onChange: (e) => updateColaborador(rep.id, c.id, { nome: e.target.value })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FotoUpload, {
								value: c.foto,
								onChange: (foto) => updateColaborador(rep.id, c.id, { foto })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: c.cargo,
								"aria-label": "Cargo",
								className: "h-10 rounded-md border border-input bg-background px-3 text-sm",
								onChange: (e) => updateColaborador(rep.id, c.id, { cargo: e.target.value }),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "consultor",
										children: "Consultor"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "supervisor",
										children: "Supervisor"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "representante",
										children: "Representante"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: c.cotas,
								"aria-label": "Cotas",
								onChange: (e) => updateColaborador(rep.id, c.id, { cotas: e.target.value === "" ? "" : Number(e.target.value) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: c.quinzena1,
								"aria-label": "Primeira quinzena",
								onChange: (e) => updateColaborador(rep.id, c.id, { quinzena1: e.target.value === "" ? "" : Number(e.target.value) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								value: c.quinzena2,
								"aria-label": "Segunda quinzena",
								onChange: (e) => updateColaborador(rep.id, c.id, { quinzena2: e.target.value === "" ? "" : Number(e.target.value) })
							}),
							isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								"aria-label": `Remover ${c.nome}`,
								onClick: () => removeColaborador(rep.id, c.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-destructive" })
							})
						]
					}, c.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: novoNome,
							placeholder: "Nome do novo colaborador",
							onChange: (e) => setNovoNome(e.target.value)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							disabled: !novoNome.trim(),
							onClick: () => {
								addColaborador(rep.id, {
									id: novoId(),
									nome: novoNome.trim(),
									cargo: "consultor",
									cotas: "",
									quinzena1: "",
									quinzena2: ""
								});
								setNovoNome("");
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Adicionar"]
						})]
					})
				]
			})]
		})]
	});
}
function Configuracoes() {
	const { dados, setMeta, addRepresentacao, resetar } = useStore();
	const { session } = useAuth();
	const isAdmin = session?.role === "admin";
	const [nome, setNome] = (0, import_react.useState)("");
	const [representante, setRepresentante] = (0, import_react.useState)("");
	const [logo, setLogo] = (0, import_react.useState)("");
	const [criando, setCriando] = (0, import_react.useState)(false);
	const lucroTotal = somaLucro(dados.representacoes);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Configurações do painel",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold",
						children: "Configurações"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Metas, representações, logos e colaboradores. As alterações são salvas no Supabase."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: resetar,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), " Restaurar padrão"]
					})]
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Meta mensal do grupo" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "flex flex-wrap items-end gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								htmlFor: "meta",
								children: "Valor da meta (R$)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "meta",
								type: "number",
								className: "w-56",
								value: dados.metaMensal,
								onChange: (e) => setMeta(Number(e.target.value) || 0)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								"Realizado atual:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: brl(lucroTotal)
								})
							]
						})]
					})]
				}),
				isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Adicionar representação" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "grid gap-4 md:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "nova-nome",
									children: "Nome"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "nova-nome",
									value: nome,
									onChange: (e) => setNome(e.target.value),
									placeholder: "Ex.: Roma"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "nova-resp",
									children: "Representante"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "nova-resp",
									value: representante,
									onChange: (e) => setRepresentante(e.target.value),
									placeholder: "Ex.: Reinaldo"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Logo" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoUpload, {
									value: logo,
									onChange: setLogo
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: async () => {
										setCriando(true);
										await addRepresentacao({
											id: novoId(),
											nome: nome.trim(),
											representante: representante.trim() || "A definir",
											logo
										});
										setCriando(false);
										setNome("");
										setRepresentante("");
										setLogo("");
									},
									disabled: !nome.trim() || !representante.trim() || criando,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }),
										" ",
										criando ? "Criando acesso..." : "Criar representação"
									]
								})
							})
						]
					})]
				}),
				dados.representacoes.map((rep) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RepEditor, {
					rep,
					isAdmin
				}, rep.id))
			]
		})
	});
}
//#endregion
export { Configuracoes as component };
