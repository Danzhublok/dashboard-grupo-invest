import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore, r as brl, u as novoId } from "./grupo-invest-logo-wQIwvroT.mjs";
import { D as ArrowDownToLine, f as Plus, s as Trash2 } from "../_libs/lucide-react.mjs";
import { a as CardHeader, i as CardContent, n as Button, o as CardTitle, r as Card, s as Input, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Label } from "./label-DCLq8y_H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/saidas-C20v_cUD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var hoje = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
function Saidas() {
	const { dados, addSaida, removeSaida } = useStore();
	const [motivo, setMotivo] = (0, import_react.useState)("");
	const [valor, setValor] = (0, import_react.useState)("");
	const [data, setData] = (0, import_react.useState)(hoje);
	const total = dados.saidas.reduce((sum, saida) => sum + saida.valor, 0);
	const adicionar = () => {
		if (!motivo.trim() || valor === "" || valor <= 0) return;
		addSaida({
			id: novoId(),
			motivo: motivo.trim(),
			valor,
			data
		});
		setMotivo("");
		setValor("");
		setData(hoje());
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Registro de saídas",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-5xl flex-col gap-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: "Saídas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Registre comissões, tráfego pago e outros custos para acompanhar o lucro líquido."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Nova saída" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-[1fr_180px_160px_auto] lg:items-end",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "motivo",
									children: "Motivo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "motivo",
									value: motivo,
									placeholder: "Ex.: Tráfego pago",
									onChange: (e) => setMotivo(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "valor-saida",
									children: "Valor (R$)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "valor-saida",
									type: "number",
									min: "0",
									value: valor,
									onChange: (e) => setValor(e.target.value === "" ? "" : Number(e.target.value))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "data-saida",
									children: "Data"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "data-saida",
									type: "date",
									value: data,
									onChange: (e) => setData(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:col-span-2 lg:col-span-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: adicionar,
									disabled: !motivo.trim() || valor === "" || valor <= 0,
									className: "w-full lg:w-auto",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Adicionar"]
								})
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "flex flex-row items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Histórico" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-semibold text-destructive",
							children: ["Total: ", brl(total)]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: dados.saidas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-2 py-10 text-center text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownToLine, { className: "size-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Nenhuma saída registrada." })]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "divide-y divide-border/60",
						children: [...dados.saidas].sort((a, b) => b.data.localeCompare(a.data)).map((saida) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-medium",
										children: saida.motivo
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: (/* @__PURE__ */ new Date(`${saida.data}T12:00:00`)).toLocaleDateString("pt-BR")
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-semibold text-destructive",
									children: ["- ", brl(saida.valor)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": `Remover saída ${saida.motivo}`,
									onClick: () => removeSaida(saida.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
								})
							]
						}, saida.id))
					}) })]
				})
			]
		})
	});
}
//#endregion
export { Saidas as component };
