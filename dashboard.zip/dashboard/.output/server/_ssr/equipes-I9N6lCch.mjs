import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore, c as lucroMensal, g as useAuth, i as cotasRep, o as lucroColaborador, r as brl } from "./grupo-invest-logo-wQIwvroT.mjs";
import { a as CardHeader, c as cn, i as CardContent, o as CardTitle, r as Card, s as Input, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Badge } from "./badge-DHIGAyFT.mjs";
import { t as Progress } from "./progress-CRGybet0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/equipes-I9N6lCch.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Table = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: "relative w-full overflow-auto",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
		ref,
		className: cn("w-full caption-bottom text-sm", className),
		...props
	})
}));
Table.displayName = "Table";
var TableHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
	ref,
	className: cn("[&_tr]:border-b", className),
	...props
}));
TableHeader.displayName = "TableHeader";
var TableBody = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
	ref,
	className: cn("[&_tr:last-child]:border-0", className),
	...props
}));
TableBody.displayName = "TableBody";
var TableFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", {
	ref,
	className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
	...props
}));
TableFooter.displayName = "TableFooter";
var TableRow = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
	ref,
	className: cn("border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted", className),
	...props
}));
TableRow.displayName = "TableRow";
var TableHead = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
	ref,
	className: cn("h-10 px-2 text-left align-middle font-medium text-muted-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableHead.displayName = "TableHead";
var TableCell = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
	ref,
	className: cn("p-2 align-middle [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]", className),
	...props
}));
TableCell.displayName = "TableCell";
var TableCaption = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("caption", {
	ref,
	className: cn("mt-4 text-sm text-muted-foreground", className),
	...props
}));
TableCaption.displayName = "TableCaption";
function Equipes() {
	const { dados, updateColaborador } = useStore();
	const { session } = useAuth();
	const isRepresentative = session?.role === "representante";
	const [busca, setBusca] = (0, import_react.useState)("");
	const termo = busca.trim().toLowerCase();
	const reps = dados.representacoes.map((r) => ({
		...r,
		colaboradores: termo ? r.colaboradores.filter((c) => c.nome.toLowerCase().includes(termo) || r.nome.toLowerCase().includes(termo)) : r.colaboradores
	})).filter((r) => !termo || r.colaboradores.length > 0 || r.nome.toLowerCase().includes(termo));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Vendas por representante e colaborador",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold",
					children: "Equipes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: isRepresentative ? "Lance as cotas e os valores de cada quinzena para acompanhar o rendimento da equipe." : "Desempenho individual dentro de cada representação."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: busca,
					onChange: (e) => setBusca(e.target.value),
					placeholder: "Buscar colaborador ou representação",
					className: "sm:w-72"
				})]
			}), reps.map((r) => {
				const total = lucroMensal(r);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "surface-card border-border/60",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
						className: "flex flex-row items-center gap-3 border-b border-border/60 pb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: r.logo,
								alt: `Logo ${r.nome}`,
								loading: "lazy",
								className: "size-11 object-contain"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
									className: "text-lg",
									children: r.nome
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: [
										"Representante: ",
										r.representante,
										" · ",
										r.colaboradores.length,
										" colaboradores"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [cotasRep(r), " cotas"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm font-semibold",
									children: brl(total)
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "pt-4",
						children: r.colaboradores.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "py-4 text-sm text-muted-foreground",
							children: "Nenhum colaborador cadastrado."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Colaborador" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Cotas"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "1ª quinzena"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "2ª quinzena"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "text-right",
								children: "Total"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
								className: "w-32",
								children: "Participação"
							})
						] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: [...r.colaboradores].sort((a, b) => lucroColaborador(b) - lucroColaborador(a)).map((c) => {
							const v = lucroColaborador(c);
							const pct = total ? v / total * 100 : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
									className: "font-medium",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: c.nome }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										className: "mt-1 text-[10px]",
										children: c.cargo
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: isRepresentative ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "0",
										value: c.cotas,
										"aria-label": `Cotas de ${c.nome}`,
										className: "ml-auto w-24 text-right",
										onChange: (event) => updateColaborador(r.id, c.id, { cotas: event.target.value === "" ? "" : Number(event.target.value) })
									}) : c.cotas
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: isRepresentative ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "0",
										value: c.quinzena1,
										"aria-label": `Primeira quinzena de ${c.nome}`,
										className: "ml-auto w-32 text-right",
										onChange: (event) => updateColaborador(r.id, c.id, { quinzena1: event.target.value === "" ? "" : Number(event.target.value) })
									}) : brl(Number(c.quinzena1 || 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right",
									children: isRepresentative ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										type: "number",
										min: "0",
										value: c.quinzena2,
										"aria-label": `Segunda quinzena de ${c.nome}`,
										className: "ml-auto w-32 text-right",
										onChange: (event) => updateColaborador(r.id, c.id, { quinzena2: event.target.value === "" ? "" : Number(event.target.value) })
									}) : brl(Number(c.quinzena2 || 0))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
									className: "text-right font-semibold",
									children: brl(v)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
										value: pct,
										className: "h-2"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-9 text-right text-xs text-muted-foreground",
										children: [pct.toFixed(0), "%"]
									})]
								}) })
							] }, c.id);
						}) })] })
					})]
				}, r.id);
			})]
		})
	});
}
//#endregion
export { Equipes as component };
