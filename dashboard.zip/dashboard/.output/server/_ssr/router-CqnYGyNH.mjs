import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as grupo_invest_logo_default, g as useAuth, n as StoreProvider, t as AuthProvider } from "./grupo-invest-logo-wQIwvroT.mjs";
import { _ as useRouter, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, l as useRouterState, m as createFileRoute, p as lazyRouteComponent, s as Scripts } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CqnYGyNH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Cfmqh28x.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$7 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Grupo Invest | Painel de Resultados" },
			{
				name: "description",
				content: "Painel de resultados da consultoria de crédito imobiliário Grupo Invest."
			},
			{
				name: "author",
				content: "Grupo Invest"
			},
			{
				property: "og:title",
				content: "Grupo Invest | Painel de Resultados"
			},
			{
				property: "og:description",
				content: "Grupo Invest. Dashboard"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			},
			{
				name: "twitter:site",
				content: "@DanielSouza"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700&family=Manrope:wght@400;500;600&display=swap"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$7.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthenticatedApp, {}) })
	});
}
function AuthenticatedApp() {
	const { session, ready, login } = useAuth();
	const router = useRouter();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	(0, import_react.useEffect)(() => {
		if (session?.role === "representante" && pathname !== "/" && pathname !== "/metas" && pathname !== "/equipes" && pathname !== "/configuracoes") router.navigate({ to: "/" });
	}, [
		pathname,
		router,
		session?.role
	]);
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	if (!ready) return null;
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border/60 bg-surface p-8 shadow-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: grupo_invest_logo_default,
							alt: "Grupo Invest",
							width: 96,
							height: 96,
							className: "mx-auto mb-4 h-24 w-24 rounded-3xl bg-background object-contain p-3 shadow-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-3xl font-bold",
							children: "Grupo Invest"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Entre para acessar seu painel."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: async (event) => {
						event.preventDefault();
						const message = await login(email, password);
						setError(message ?? "");
					},
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium text-foreground",
							children: ["E-mail ou usuário", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: email,
								onChange: (event) => setEmail(event.target.value),
								className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20",
								autoComplete: "username"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium text-foreground",
							children: ["Senha", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								value: password,
								onChange: (event) => setPassword(event.target.value),
								className: "mt-2 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20",
								autoComplete: "current-password"
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "inline-flex w-full items-center justify-center rounded-xl bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground transition hover:bg-primary/90",
							children: "Entrar"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-center text-xs text-muted-foreground",
					children: [
						"Insira seu: ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Login" }),
						" / ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "E senha" })
					]
				})
			]
		})
	});
	if (session.role === "representante" && pathname !== "/" && pathname !== "/metas" && pathname !== "/equipes" && pathname !== "/configuracoes") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreProvider, {
		representationId: session.role === "representante" ? session.representationId : void 0,
		representationName: session.role === "representante" ? session.representationName : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$6 = () => import("./routes-Bk596BjQ.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Dashboard de Lucros | Grupo Invest" },
		{
			name: "description",
			content: "Painel de resultados das representações do Grupo Invest: lucro mensal, quinzenal e cotas de crédito imobiliário."
		},
		{
			property: "og:title",
			content: "Dashboard de Lucros | Grupo Invest"
		},
		{
			property: "og:description",
			content: "Acompanhe o lucro mensal e quinzenal de cada representação do Grupo Invest."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./configuracoes-o2helFTk.mjs");
var Route$5 = createFileRoute("/configuracoes")({
	head: () => ({ meta: [
		{ title: "Configurações | Grupo Invest" },
		{
			name: "description",
			content: "Configure metas, adicione ou remova representações e gerencie colaboradores do Grupo Invest."
		},
		{
			property: "og:title",
			content: "Configurações | Grupo Invest"
		},
		{
			property: "og:description",
			content: "Gestão de metas, representações, logos e colaboradores."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./equipes-I9N6lCch.mjs");
var Route$4 = createFileRoute("/equipes")({
	head: () => ({ meta: [
		{ title: "Vendas por Colaborador | Grupo Invest" },
		{
			name: "description",
			content: "Desempenho individual de representantes e colaboradores de cada representação do Grupo Invest."
		},
		{
			property: "og:title",
			content: "Vendas por Colaborador | Grupo Invest"
		},
		{
			property: "og:description",
			content: "Veja as vendas de cada colaborador dentro da sua representação."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./metas-DK5AcEZg.mjs");
var Route$3 = createFileRoute("/metas")({
	head: () => ({ meta: [
		{ title: "Metas de Vendas | Grupo Invest" },
		{
			name: "description",
			content: "Acompanhe o progresso da meta mensal do Grupo Invest: ganho total, valor atual e quanto falta para bater o objetivo."
		},
		{
			property: "og:title",
			content: "Metas de Vendas | Grupo Invest"
		},
		{
			property: "og:description",
			content: "Progresso da meta mensal do Grupo Invest em nível de empresa."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./saidas-C20v_cUD.mjs");
var Route$2 = createFileRoute("/saidas")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./usuarios-CMNxxk0U.mjs");
var Route$1 = createFileRoute("/usuarios")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./vendas-DAU1Mcox.mjs");
var Route = createFileRoute("/vendas")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	ConfiguracoesRoute: Route$5.update({
		id: "/configuracoes",
		path: "/configuracoes",
		getParentRoute: () => Route$7
	}),
	EquipesRoute: Route$4.update({
		id: "/equipes",
		path: "/equipes",
		getParentRoute: () => Route$7
	}),
	MetasRoute: Route$3.update({
		id: "/metas",
		path: "/metas",
		getParentRoute: () => Route$7
	}),
	SaidasRoute: Route$2.update({
		id: "/saidas",
		path: "/saidas",
		getParentRoute: () => Route$7
	}),
	UsuariosRoute: Route$1.update({
		id: "/usuarios",
		path: "/usuarios",
		getParentRoute: () => Route$7
	}),
	VendasRoute: Route.update({
		id: "/vendas",
		path: "/vendas",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
