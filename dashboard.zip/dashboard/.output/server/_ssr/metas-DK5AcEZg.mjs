import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore, a as grupo_invest_logo_default, c as lucroMensal, g as useAuth, m as somaLucro, o as lucroColaborador, r as brl } from "./grupo-invest-logo-wQIwvroT.mjs";
import { T as Check, g as Maximize2, h as Minimize2, u as Save } from "../_libs/lucide-react.mjs";
import { a as CardHeader, i as CardContent, n as Button, o as CardTitle, r as Card, s as Input, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Label } from "./label-DCLq8y_H.mjs";
import { t as Progress } from "./progress-CRGybet0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/metas-DK5AcEZg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Metas() {
	const { dados, setMetaEquipe, setMetaColaborador, setMeta } = useStore();
	const { session } = useAuth();
	const { representacoes, metaMensal } = dados;
	const isAdmin = session?.role === "admin";
	const representation = representacoes[0];
	const lucroTotal = somaLucro(representacoes);
	const lucroExibido = isAdmin && representation ? lucroTotal : representation ? lucroMensal(representation) : 0;
	const metaExibida = isAdmin ? metaMensal : representation ? dados.metasEquipe[representation.id] ?? 0 : 0;
	const progresso = metaExibida ? Math.min(100, lucroExibido / metaExibida * 100) : 0;
	const falta = Math.max(0, metaExibida - lucroExibido);
	const [metaEmpresaDraft, setMetaEmpresaDraft] = (0, import_react.useState)(metaMensal);
	const [metaEquipeDraft, setMetaEquipeDraft] = (0, import_react.useState)({});
	const [metasColaboradorDraft, setMetasColaboradorDraft] = (0, import_react.useState)({});
	const [isFullscreen, setIsFullscreen] = (0, import_react.useState)(false);
	const progressRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setMetaEmpresaDraft(metaMensal);
		setMetaEquipeDraft(Object.fromEntries(representacoes.map((item) => [item.id, dados.metasEquipe[item.id] ?? ""])));
		setMetasColaboradorDraft(dados.metasColaborador);
	}, [
		dados.metasColaborador,
		dados.metasEquipe,
		metaMensal,
		representacoes,
		representation
	]);
	(0, import_react.useEffect)(() => {
		if (typeof document === "undefined") return;
		const updateFullscreenState = () => setIsFullscreen(Boolean(document.fullscreenElement));
		updateFullscreenState();
		document.addEventListener("fullscreenchange", updateFullscreenState);
		return () => document.removeEventListener("fullscreenchange", updateFullscreenState);
	}, []);
	const handleToggleFullscreen = async () => {
		if (typeof document === "undefined") return;
		try {
			if (document.fullscreenElement) await document.exitFullscreen();
			else if (progressRef.current?.requestFullscreen) await progressRef.current.requestFullscreen();
		} catch (error) {
			console.error(error);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Metas e progresso de vendas",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				ref: progressRef,
				className: "hero-gradient rounded-3xl px-6 py-10 text-primary-foreground shadow-[var(--shadow-glow)] md:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-6 md:flex-row md:items-center md:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: grupo_invest_logo_default,
								alt: "Logo Grupo Invest",
								width: 64,
								height: 64,
								className: "h-16 w-16 rounded-2xl bg-background object-contain p-2 shadow-sm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs uppercase tracking-[0.3em] opacity-80",
									children: "Meta do mês"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-2 text-3xl font-bold md:text-4xl",
									children: [progresso.toFixed(1), "% da meta alcançada"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm opacity-85",
									children: [
										brl(lucroExibido),
										" de ",
										brl(metaExibida)
									]
								})
							] })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: handleToggleFullscreen,
							className: "self-start",
							children: isFullscreen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minimize2, { className: "mr-2 h-4 w-4" }), "Sair da tela cheia"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "mr-2 h-4 w-4" }), "Tela cheia"] })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
							value: progresso,
							className: "h-6 bg-background/30"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "surface-card border-border/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Ganho total" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold",
								children: brl(lucroExibido)
							}) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "surface-card border-border/60",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Falta para bater" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-2xl font-semibold text-accent",
								children: brl(falta)
							}) })]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold",
						children: "Metas por equipe e colaborador"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: session?.role === "admin" ? "Defina as metas de cada representação." : "Acompanhe as metas da sua representação."
					})] }),
					isAdmin && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "surface-card border-border/60",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "flex flex-wrap items-end gap-3 p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "meta-empresa",
									children: "Meta da empresa"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "meta-empresa",
									type: "number",
									value: metaEmpresaDraft,
									onChange: (event) => setMetaEmpresaDraft(event.target.value === "" ? 0 : Number(event.target.value))
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => setMeta(metaEmpresaDraft),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Salvar meta da empresa"]
							})]
						})
					}),
					representacoes.map((representation) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
								className: "flex flex-row items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, { children: ["Meta da equipe ", representation.nome] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										"Realizado: ",
										brl(lucroMensal(representation)),
										" · Meta:",
										" ",
										brl(dados.metasEquipe[representation.id] ?? 0)
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
											htmlFor: `meta-equipe-${representation.id}`,
											className: "sr-only",
											children: "Meta da equipe"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											id: `meta-equipe-${representation.id}`,
											type: "number",
											className: "w-36",
											value: metaEquipeDraft[representation.id] ?? "",
											onChange: (event) => setMetaEquipeDraft((current) => ({
												...current,
												[representation.id]: event.target.value === "" ? "" : Number(event.target.value)
											})),
											placeholder: "Meta equipe"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											onClick: () => setMetaEquipe(representation.id, Number(metaEquipeDraft[representation.id] || 0)),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "size-4" }), " Salvar"]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
								className: "pb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
									value: dados.metasEquipe[representation.id] ? Math.min(100, lucroMensal(representation) / dados.metasEquipe[representation.id] * 100) : 0,
									className: "h-3"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: [
										"Falta:",
										" ",
										brl(Math.max(0, (dados.metasEquipe[representation.id] ?? 0) - lucroMensal(representation)))
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "space-y-2",
								children: representation.colaboradores.map((collaborator) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 border-t border-border/60 py-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex-1 text-sm",
											children: collaborator.nome
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs text-muted-foreground",
											children: [
												"Realizado ",
												brl(lucroColaborador(collaborator)),
												" · Falta",
												" ",
												brl(Math.max(0, (dados.metasColaborador[collaborator.id] ?? 0) - lucroColaborador(collaborator)))
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
											type: "number",
											className: "w-32",
											value: metasColaboradorDraft[collaborator.id] ?? "",
											onChange: (event) => setMetasColaboradorDraft((current) => ({
												...current,
												[collaborator.id]: event.target.value === "" ? "" : Number(event.target.value)
											})),
											placeholder: "Meta pessoal"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											size: "sm",
											variant: "outline",
											onClick: () => setMetaColaborador(collaborator.id, Number(metasColaboradorDraft[collaborator.id] || 0)),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), " Salvar"]
										})
									]
								}, collaborator.id))
							})
						]
					}, representation.id))
				]
			})]
		})
	});
}
//#endregion
export { Metas as component };
