import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { _ as useStore, a as grupo_invest_logo_default, c as lucroMensal, d as quinzena1Rep, f as quinzena2Rep, g as useAuth, h as somaLucroPorPeriodo, i as cotasRep, l as lucroRepresentacaoPorPeriodo, p as somaCotas, r as brl, s as lucroColaboradorPorPeriodo } from "./grupo-invest-logo-wQIwvroT.mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Coins, D as ArrowDownToLine, E as CalendarDays, n as Wallet, o as TrendingUp, r as Users } from "../_libs/lucide-react.mjs";
import { a as CardHeader, i as CardContent, n as Button, o as CardTitle, r as Card, t as AppLayout } from "./card-C5UwDbMu.mjs";
import { t as Badge } from "./badge-DHIGAyFT.mjs";
import { a as Tooltip, i as ResponsiveContainer, n as Pie, o as Legend, r as Cell, t as PieChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bk596BjQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CHART_COLORS = [
	"var(--chart-1)",
	"var(--chart-2)",
	"var(--chart-3)",
	"var(--chart-4)",
	"var(--chart-5)"
];
function KpiCard({ icon: Icon, label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "surface-card border-border/60",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex items-center gap-4 p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-11 items-center justify-center rounded-xl bg-secondary text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wide text-muted-foreground",
					children: label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-2xl font-semibold text-foreground",
					children: value
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: hint
				})
			] })]
		})
	});
}
function Dashboard() {
	const { dados } = useStore();
	const { session } = useAuth();
	const [mesSelecionado, setMesSelecionado] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 7));
	const [periodoSelecionado, setPeriodoSelecionado] = (0, import_react.useState)("geral");
	const representacoes = dados.representacoes;
	const ganhoTotal = somaLucroPorPeriodo(representacoes, periodoSelecionado);
	const saidasMes = dados.saidas.filter((saida) => saida.data.startsWith(mesSelecionado));
	const saidasAnterior = dados.saidas.filter((saida) => saida.data.startsWith(mesAnterior(mesSelecionado)));
	const totalSaidas = saidasMes.reduce((sum, saida) => sum + saida.valor, 0);
	const totalSaidasAnterior = saidasAnterior.reduce((sum, saida) => sum + saida.valor, 0);
	const lucroMes = ganhoTotal - totalSaidas;
	const cotasTotais = somaCotas(representacoes);
	const ticketMedio = cotasTotais ? Math.round(ganhoTotal / cotasTotais) : 0;
	const ranking = [...representacoes].sort((a, b) => lucroRepresentacaoPorPeriodo(b, periodoSelecionado) - lucroRepresentacaoPorPeriodo(a, periodoSelecionado));
	const lider = ranking[0];
	const pieData = representacoes.map((r) => ({
		name: r.nome,
		value: lucroRepresentacaoPorPeriodo(r, periodoSelecionado)
	}));
	const individualPieData = representacoes.flatMap((representation) => representation.colaboradores.map((collaborator) => ({
		name: collaborator.nome,
		value: lucroColaboradorPorPeriodo(collaborator, periodoSelecionado)
	})));
	const vendedores = representacoes.flatMap((r) => r.colaboradores.filter((c) => c.cargo === "consultor").map((c) => ({
		...c,
		logo: r.logo
	})));
	const supervisores = representacoes.flatMap((r) => r.colaboradores.filter((c) => c.cargo === "supervisor").map((c) => ({
		...c,
		logo: r.logo
	})));
	const periodoLabel = {
		geral: "Geral",
		quinzena1: "1ª Quinzena",
		quinzena2: "2ª Quinzena"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppLayout, {
		title: "Visão geral das representações",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-7xl flex-col gap-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "hero-gradient relative overflow-hidden rounded-3xl px-6 py-10 text-primary-foreground shadow-[var(--shadow-glow)] md:px-12 md:py-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center gap-6 text-center md:flex-row md:text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: grupo_invest_logo_default,
							alt: "Logo Grupo Invest — Investimentos & Consórcios",
							width: 128,
							height: 128,
							className: "size-28 rounded-2xl bg-background object-contain p-2 shadow-lg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-[0.3em] opacity-80",
								children: "Investimentos & Consórcios"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-2 text-3xl font-bold md:text-4xl",
								children: "Painel de Resultados — Grupo Invest"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-2xl text-sm opacity-85 md:text-base",
								children: "Consultoria de crédito imobiliário · lucro mensal e quinzenal por representação e colaborador."
							})
						] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold text-muted-foreground",
							children: "Selecionar período"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "inline-flex items-center gap-1 rounded-full border border-border/80 bg-card/90 p-1 shadow-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: periodoSelecionado === "geral" ? "default" : "ghost",
									size: "sm",
									onClick: () => setPeriodoSelecionado("geral"),
									className: "rounded-full px-4",
									"aria-pressed": periodoSelecionado === "geral",
									children: "Geral"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: periodoSelecionado === "quinzena1" ? "default" : "ghost",
									size: "sm",
									onClick: () => setPeriodoSelecionado("quinzena1"),
									className: "rounded-full px-4",
									"aria-pressed": periodoSelecionado === "quinzena1",
									children: "1ª Quinzena"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: periodoSelecionado === "quinzena2" ? "default" : "ghost",
									size: "sm",
									onClick: () => setPeriodoSelecionado("quinzena2"),
									className: "rounded-full px-4",
									"aria-pressed": periodoSelecionado === "quinzena2",
									children: "2ª Quinzena"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-full border border-border/60 bg-background/50 px-4 py-2 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground",
						children: periodoLabel[periodoSelecionado]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: Wallet,
							label: "Lucro total",
							value: brl(lucroMes),
							hint: "Ganho menos saídas do período"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: Coins,
							label: "Cotas vendidas",
							value: String(cotasTotais),
							hint: "Todas as representações"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: TrendingUp,
							label: "Ticket médio / cota",
							value: brl(ticketMedio),
							hint: "Lucro médio por cota"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: Users,
							label: "Representação líder",
							value: lider ? lider.nome : "—",
							hint: lider ? `${brl(lucroRepresentacaoPorPeriodo(lider, periodoSelecionado))} em ${periodoLabel[periodoSelecionado]}` : "Cadastre uma representação"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: TrendingUp,
							label: "Ganho do período",
							value: brl(ganhoTotal),
							hint: `${periodoLabel[periodoSelecionado]} · vendas das representações`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, {
							icon: ArrowDownToLine,
							label: "Saídas",
							value: brl(totalSaidas),
							hint: "Custos registrados no período"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "surface-card border-border/60",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "flex flex-wrap items-end gap-4 p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									htmlFor: "mes-dashboard",
									className: "text-sm font-medium",
									children: "Comparar mês"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-4 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "mes-dashboard",
										type: "month",
										value: mesSelecionado,
										onChange: (e) => setMesSelecionado(e.target.value),
										className: "h-10 rounded-md border border-input bg-background px-3 text-sm"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm text-muted-foreground",
								children: ["Saídas do mês: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: brl(totalSaidas)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm text-muted-foreground",
								children: ["Mês anterior: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: brl(totalSaidasAnterior)
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-6 lg:grid-cols-[1.2fr_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: session?.role === "admin" ? "Participação no lucro por representação" : "Participação no lucro por colaborador" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "h-[340px]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
										data: session?.role === "admin" ? pieData : individualPieData,
										dataKey: "value",
										nameKey: "name",
										innerRadius: 70,
										outerRadius: 115,
										paddingAngle: 3,
										isAnimationActive: false,
										children: (session?.role === "admin" ? pieData : individualPieData).map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: CHART_COLORS[i % CHART_COLORS.length] }, entry.name))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { formatter: (v) => brl(v) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, {})
								] })
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Ranking das representações" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "space-y-3",
							children: ranking.slice(0, 3).map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-xl border border-border/60 bg-background/60 p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "w-6 text-sm font-semibold text-muted-foreground",
										children: [i + 1, "º"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: r.logo,
										alt: `Logo ${r.nome}`,
										loading: "lazy",
										className: "size-9 object-contain"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium",
											children: r.nome
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: [
												cotasRep(r),
												" cotas · ",
												r.representante
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold",
										children: brl(lucroMensal(r))
									})
								]
							}, r.id))
						})]
					})]
				}),
				session?.role === "admin" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-6 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankingCard, {
						title: "Top 3 vendedores",
						periodo: periodoSelecionado,
						entries: vendedores.sort((a, b) => lucroColaboradorPorPeriodo(b, periodoSelecionado) - lucroColaboradorPorPeriodo(a, periodoSelecionado)).slice(0, 3)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankingCard, {
						title: "Top 3 supervisores",
						periodo: periodoSelecionado,
						entries: supervisores.sort((a, b) => lucroColaboradorPorPeriodo(b, periodoSelecionado) - lucroColaboradorPorPeriodo(a, periodoSelecionado)).slice(0, 3)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "grid gap-6 md:grid-cols-2 xl:grid-cols-3",
					children: representacoes.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "surface-card overflow-hidden border-border/60",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
							className: "flex flex-row items-center gap-3 border-b border-border/60 pb-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: r.logo,
									alt: `Logo da representação ${r.nome}`,
									loading: "lazy",
									className: "size-12 object-contain"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
										className: "text-lg",
										children: r.nome
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: ["Representante: ", r.representante]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									variant: "secondary",
									children: [cotasRep(r), " cotas"]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
							className: "pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
								className: "w-full text-sm",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-muted-foreground",
											children: "1ª quinzena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-right font-medium",
											children: brl(quinzena1Rep(r))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-muted-foreground",
											children: "2ª quinzena"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 text-right font-medium",
											children: brl(quinzena2Rep(r))
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "pt-3 font-semibold",
										children: "Lucro mensal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "pt-3 text-right text-lg font-bold text-accent",
										children: brl(lucroMensal(r))
									})] })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/equipes",
								className: "mt-4 inline-flex text-xs font-medium text-primary hover:underline",
								children: [
									"Ver ",
									r.colaboradores.length,
									" colaboradores →"
								]
							})]
						})]
					}, r.id))
				})
			]
		})
	});
}
function mesAnterior(mes) {
	const [ano, numero] = mes.split("-").map(Number);
	const data = new Date(ano, numero - 2, 1);
	return `${data.getFullYear()}-${String(data.getMonth() + 1).padStart(2, "0")}`;
}
function RankingCard({ title, entries, periodo }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "surface-card border-border/60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: title }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "space-y-3",
			children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Atribua cargos aos colaboradores para formar este ranking."
			}) : entries.map((entry, index) => {
				const valorRanking = periodo === "quinzena1" ? Number(entry.quinzena1 || 0) : periodo === "quinzena2" ? Number(entry.quinzena2 || 0) : Number(entry.quinzena1 || 0) + Number(entry.quinzena2 || 0);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-xl border border-border/60 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "w-6 font-semibold text-muted-foreground",
							children: [index + 1, "º"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: entry.foto || entry.logo,
							alt: `Foto de ${entry.nome}`,
							className: "size-10 rounded-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 font-medium",
							children: entry.nome
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: brl(valorRanking)
						})
					]
				}, `${entry.id}-${entry.logo}`);
			})
		})]
	});
}
//#endregion
export { Dashboard as component };
