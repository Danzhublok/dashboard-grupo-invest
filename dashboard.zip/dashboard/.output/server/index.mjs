globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/badge-C6WceqJE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"302-CAL7PST1hD3Cv2O/QHSOUjg0r8U\"",
		"mtime": "2026-08-10T02:47:57.493Z",
		"size": 770,
		"path": "../public/assets/badge-C6WceqJE.js"
	},
	"/assets/card-CcXFN_wX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e7ad-sJAk8f9cuy9OT80LmxNDtWpX/JI\"",
		"mtime": "2026-08-10T02:47:57.493Z",
		"size": 124845,
		"path": "../public/assets/card-CcXFN_wX.js"
	},
	"/assets/check-CJFMYDIZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"70-keQ/ZPO5PvrhC+CkkWqKhtt0J8A\"",
		"mtime": "2026-08-10T02:47:57.493Z",
		"size": 112,
		"path": "../public/assets/check-CJFMYDIZ.js"
	},
	"/assets/configuracoes-DcwBVkjy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2352-5Cgs0Pv9vqrqzFcO3KptzVLgA90\"",
		"mtime": "2026-08-10T02:47:57.494Z",
		"size": 9042,
		"path": "../public/assets/configuracoes-DcwBVkjy.js"
	},
	"/assets/equipes-DdtRrLQK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1603-mnIeSx5sUX54yRZz3uiaXcOjU1g\"",
		"mtime": "2026-08-10T02:47:57.495Z",
		"size": 5635,
		"path": "../public/assets/equipes-DdtRrLQK.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-07-30T02:52:58.000Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/label-BbYtX382.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"286-ryx1pJzgcq56gm82uN+LmtzkCJ4\"",
		"mtime": "2026-08-10T02:47:57.496Z",
		"size": 646,
		"path": "../public/assets/label-BbYtX382.js"
	},
	"/assets/plus-Dncz5Ier.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-nZHekjbGd+fhH/NwFjOY38bincE\"",
		"mtime": "2026-08-10T02:47:57.497Z",
		"size": 141,
		"path": "../public/assets/plus-Dncz5Ier.js"
	},
	"/assets/metas-BuJT-Dny.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1832-2o0iVaP92/SjxcOuCXJOlr9I7TI\"",
		"mtime": "2026-08-10T02:47:57.497Z",
		"size": 6194,
		"path": "../public/assets/metas-BuJT-Dny.js"
	},
	"/assets/progress-DCIghpQp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a9-6gUvKgRkIFBropStc6Ighz0z7rQ\"",
		"mtime": "2026-08-10T02:47:57.497Z",
		"size": 2217,
		"path": "../public/assets/progress-DCIghpQp.js"
	},
	"/assets/grupo-invest-logo-BYs1KUjT.jpg": {
		"type": "image/jpeg",
		"etag": "\"ea46-wteqbAgexMH8ZNNgmOfnIUEmsKM\"",
		"mtime": "2026-08-10T02:47:57.503Z",
		"size": 59974,
		"path": "../public/assets/grupo-invest-logo-BYs1KUjT.jpg"
	},
	"/assets/saidas-CfCm6MhY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf3-ZNN4Ayji9VrFXkTQjfKv1A+Qv78\"",
		"mtime": "2026-08-10T02:47:57.500Z",
		"size": 3315,
		"path": "../public/assets/saidas-CfCm6MhY.js"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4203e-cU82Pp0IsPiQXhosTKNGzvPUQP4\"",
		"mtime": "2026-07-30T03:13:58.350Z",
		"size": 270398,
		"path": "../public/favicon.ico"
	},
	"/assets/save-fQTSOchD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13b-YQvVEt4GJQbsGH1lbzzgiBetwSE\"",
		"mtime": "2026-08-10T02:47:57.502Z",
		"size": 315,
		"path": "../public/assets/save-fQTSOchD.js"
	},
	"/assets/trash-2-CQPgam-I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-yZliaf2jNjUxqd8PKXI0MbosTZc\"",
		"mtime": "2026-08-10T02:47:57.502Z",
		"size": 316,
		"path": "../public/assets/trash-2-CQPgam-I.js"
	},
	"/assets/usuarios-BGeTS95k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c08-ZhT8KBNxWQ+XLF/aVCPEznZc8/0\"",
		"mtime": "2026-08-10T02:47:57.502Z",
		"size": 7176,
		"path": "../public/assets/usuarios-BGeTS95k.js"
	},
	"/assets/vendas-BjTADyXQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d5-a9nh+4rbWI63tqOJy6+W+ZhTAmQ\"",
		"mtime": "2026-08-10T02:47:57.503Z",
		"size": 8405,
		"path": "../public/assets/vendas-BjTADyXQ.js"
	},
	"/assets/styles-Cfmqh28x.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"13f0d-Bqo4uRfuFjVht+MjApT0erY7Sps\"",
		"mtime": "2026-08-10T02:47:57.505Z",
		"size": 81677,
		"path": "../public/assets/styles-Cfmqh28x.css"
	},
	"/assets/routes-ylRt1XNQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5977b-nAgyQ1viKcV7T28XrJZWk8N9JGU\"",
		"mtime": "2026-08-10T02:47:57.500Z",
		"size": 366459,
		"path": "../public/assets/routes-ylRt1XNQ.js"
	},
	"/assets/index-B1wzdGa7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ba08-IUgxJ6b0MJ0cgw+zs8iDdJnyGFE\"",
		"mtime": "2026-08-10T02:47:57.491Z",
		"size": 571912,
		"path": "../public/assets/index-B1wzdGa7.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_U_hgvE = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_U_hgvE
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
