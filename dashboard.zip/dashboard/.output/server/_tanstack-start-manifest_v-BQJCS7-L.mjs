//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BQJCS7-L.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/__root.tsx",
		children: [
			"/",
			"/configuracoes",
			"/equipes",
			"/metas",
			"/saidas",
			"/usuarios",
			"/vendas"
		],
		preloads: ["/assets/index-B1wzdGa7.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B1wzdGa7.js"
		} }]
	},
	"/": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-ylRt1XNQ.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/badge-C6WceqJE.js"
		]
	},
	"/configuracoes": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/configuracoes.tsx",
		children: void 0,
		preloads: [
			"/assets/configuracoes-DcwBVkjy.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/check-CJFMYDIZ.js",
			"/assets/plus-Dncz5Ier.js",
			"/assets/trash-2-CQPgam-I.js",
			"/assets/label-BbYtX382.js"
		]
	},
	"/equipes": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/equipes.tsx",
		children: void 0,
		preloads: [
			"/assets/equipes-DdtRrLQK.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/badge-C6WceqJE.js",
			"/assets/progress-DCIghpQp.js"
		]
	},
	"/metas": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/metas.tsx",
		children: void 0,
		preloads: [
			"/assets/metas-BuJT-Dny.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/check-CJFMYDIZ.js",
			"/assets/save-fQTSOchD.js",
			"/assets/label-BbYtX382.js",
			"/assets/progress-DCIghpQp.js"
		]
	},
	"/saidas": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/saidas.tsx",
		children: void 0,
		preloads: [
			"/assets/saidas-CfCm6MhY.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/plus-Dncz5Ier.js",
			"/assets/trash-2-CQPgam-I.js",
			"/assets/label-BbYtX382.js"
		]
	},
	"/usuarios": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/usuarios.tsx",
		children: void 0,
		preloads: [
			"/assets/usuarios-BGeTS95k.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/check-CJFMYDIZ.js",
			"/assets/save-fQTSOchD.js",
			"/assets/trash-2-CQPgam-I.js",
			"/assets/label-BbYtX382.js"
		]
	},
	"/vendas": {
		filePath: "D:/projetos/real-estate-profit-pro-main/src/routes/vendas.tsx",
		children: void 0,
		preloads: [
			"/assets/vendas-BjTADyXQ.js",
			"/assets/card-CcXFN_wX.js",
			"/assets/plus-Dncz5Ier.js",
			"/assets/badge-C6WceqJE.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
